
<?php
include 'config.php';

if (isset($_POST['simpan'])) {
    $id = $_POST['PelangganID'];
    $nama = $_POST['NamaPelanggan'];
    $alamat = $_POST['Alamat'];
    $telepon = $_POST['NomorTelepon'];

    if ($id == "") {
    
        $query = mysqli_prepare($conn, 
            "INSERT INTO pelanggann (NamaPelanggan, Alamat, NomorTelepon)
             VALUES (?, ?, ?)"
        );
        mysqli_stmt_bind_param($query, "sss", $nama, $alamat, $telepon);
    } else {
     
        $query = mysqli_prepare($conn,
            "UPDATE pelanggann SET NamaPelanggan=?, Alamat=?, NomorTelepon=?
             WHERE PelangganID=?"
        );
        mysqli_stmt_bind_param($query, "sssi", $nama, $alamat, $telepon, $id);
    }

    mysqli_stmt_execute($query);
    header("Location: pelanggan.php");
    exit;
}

if (isset($_GET['hapus'])) {
    $id = (int) $_GET['hapus'];

    $query = mysqli_prepare($conn,
        "DELETE FROM pelanggann WHERE PelangganID=?"
    );
    mysqli_stmt_bind_param($query, "i", $id);
    mysqli_stmt_execute($query);

    header("Location: pelanggan.php");
    exit;
}

$edit = null;

if (isset($_GET['edit'])) {
    $id = (int) $_GET['edit'];

    $queryEdit = mysqli_query($conn,
        "SELECT * FROM pelanggann WHERE PelangganID=$id"
    );

    $edit = mysqli_fetch_assoc($queryEdit);
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Data Pelanggan</title>
     <link rel="stylesheet" href="style.css">
</head>
<body>

<h2>DATA PELANGGAN</h2>

<hr>

<h3><?php echo $edit ? "Edit Pelanggan" : "Tambah Pelanggan"; ?></h3>

<form method="POST" action="">

    <input type="hidden" name="PelangganID"
    value="<?php echo $edit['PelangganID'] ?? ''; ?>">

    <label>Nama Pelanggan</label><br>
    <input type="text" name="NamaPelanggan"
    value="<?php echo htmlspecialchars($edit['NamaPelanggan'] ?? ''); ?>"
    required>
    <br><br>

    <label>Alamat</label><br>
    <textarea name="Alamat" required><?php
        echo htmlspecialchars($edit['Alamat'] ?? '');
    ?></textarea>
    <br><br>

    <label>Nomor Telepon</label><br>
    <input type="text" name="NomorTelepon"
    value="<?php echo htmlspecialchars($edit['NomorTelepon'] ?? ''); ?>"
    maxlength="15" required>
    <br><br>

    <button type="submit" name="simpan">
        <?php echo $edit ? "Update Pelanggan" : "Simpan Pelanggan"; ?>
    </button>

    <?php if ($edit) { ?>
        <a href="pelanggan.php">Batal</a>
    <?php } ?>

</form>

<hr>

<h3>Daftar Pelanggan</h3>

<table border="1" cellpadding="10" cellspacing="0">
    <tr>
        <th>No</th>
        <th>ID Pelanggan</th>
        <th>Nama Pelanggan</th>
        <th>Alamat</th>
        <th>Nomor Telepon</th>
        <th>Aksi</th>
    </tr>

    <?php
    $no = 1;
    $data = mysqli_query($conn, "SELECT * FROM pelanggann ORDER BY PelangganID DESC");

    while ($row = mysqli_fetch_assoc($data)) {
    ?>

    <tr>
        <td><?php echo $no++; ?></td>
        <td><?php echo $row['PelangganID']; ?></td>
        <td><?php echo htmlspecialchars($row['NamaPelanggan']); ?></td>
        <td><?php echo htmlspecialchars($row['Alamat']); ?></td>
        <td><?php echo htmlspecialchars($row['NomorTelepon']); ?></td>

        <td>
            <a href="pelanggan.php?edit=<?php echo $row['PelangganID']; ?>">
                Edit
            </a>

            |

            <a href="pelanggan.php?hapus=<?php echo $row['PelangganID']; ?>"
            onclick="return confirm('Yakin ingin menghapus pelanggan ini?')">
                Hapus
            </a>
        </td>
    </tr>

    <?php } ?>

</table>

<br>
<a href="index.php">Kembali ke Dashboard</a>

</body>
</html>
