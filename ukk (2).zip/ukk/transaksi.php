
<?php
include 'config.php';
$pesan = "";

if (isset($_POST['simpan'])) {

    $namaPelanggan = trim($_POST['pelanggan']);
    $namaProduk = $_POST['produk'];
    $jumlahProduk = $_POST['jumlah'];

    $stmt = $conn->prepare(
        "SELECT PelangganID FROM pelanggann WHERE NamaPelanggan = ?"
    );
    $stmt->bind_param("s", $namaPelanggan);
    $stmt->execute();
    $pelanggan = $stmt->get_result()->fetch_assoc();

    if (!$pelanggan) {
        $pesan = "Pelanggan tidak ditemukan!";
    } else {

        $dataBarang = [];
        $totalHarga = 0;
        $valid = true;

        foreach ($namaProduk as $i => $nama) {

            $nama = trim($nama);
            $jumlah = (int)$jumlahProduk[$i];

            if ($nama == "" && $jumlah == 0) {
                continue;
            }

            if ($nama == "" || $jumlah <= 0) {
                $valid = false;
                $pesan = "Nama barang dan jumlah harus diisi!";
                break;
            }

            $stmt = $conn->prepare(
                "SELECT ProdukID, Harga, Stok
                 FROM produkk
                 WHERE NamaProduk = ?"
            );

            $stmt->bind_param("s", $nama);
            $stmt->execute();
            $barang = $stmt->get_result()->fetch_assoc();

            if (!$barang) {
                $valid = false;
                $pesan = "Barang tidak ditemukan!";
                break;
            }

            if ($barang['Stok'] < $jumlah) {
                $valid = false;
                $pesan = "Stok barang tidak mencukupi!";
                break;
            }

            $subtotal = $barang['Harga'] * $jumlah;
            $totalHarga += $subtotal;

            $dataBarang[] = [
                'id' => $barang['ProdukID'],
                'jumlah' => $jumlah,
                'subtotal' => $subtotal
            ];
        }

        if ($valid && count($dataBarang) == 0) {
            $valid = false;
            $pesan = "Masukkan minimal satu barang!";
        }

        if ($valid) {

            $conn->begin_transaction();

            try {

                $tanggal = date('Y-m-d');
                $pelangganID = $pelanggan['PelangganID'];

                $stmt = $conn->prepare(
                    "INSERT INTO penjualann
                    (TanggalPenjualan, TotalHarga, PelangganID)
                    VALUES (?, ?, ?)"
                );

                $stmt->bind_param(
                    "sdi",
                    $tanggal,
                    $totalHarga,
                    $pelangganID
                );

                $stmt->execute();

                $penjualanID = $conn->insert_id;

                foreach ($dataBarang as $barang) {

                    $stmt = $conn->prepare(
                        "INSERT INTO detailpenjualann
                        (PenjualanID, ProdukID, JumlahProduk, Subtotal)
                        VALUES (?, ?, ?, ?)"
                    );

                    $stmt->bind_param(
                        "iiid",
                        $penjualanID,
                        $barang['id'],
                        $barang['jumlah'],
                        $barang['subtotal']
                    );

                    $stmt->execute();

                    $stmt = $conn->prepare(
                        "UPDATE produkk
                         SET Stok = Stok - ?
                         WHERE ProdukID = ? AND Stok >= ?"
                    );

                    $stmt->bind_param(
                        "iii",
                        $barang['jumlah'],
                        $barang['id'],
                        $barang['jumlah']
                    );

                    $stmt->execute();

                    if ($stmt->affected_rows != 1) {
                        throw new Exception("Stok tidak mencukupi!");
                    }
                }

                $conn->commit();

                header("Location: transaksi.php?pesan=berhasil");
                exit;

            } catch (Exception $e) {

                $conn->rollback();
                $pesan = "Transaksi gagal disimpan!";
            }
        }
    }
}

if (isset($_GET['pesan'])) {
    if ($_GET['pesan'] == 'berhasil') {
        $pesan = "Transaksi berhasil disimpan!";
    }
}

$pelangganList = $conn->query(
    "SELECT NamaPelanggan FROM pelanggann"
);

$produkList = $conn->query(
    "SELECT NamaProduk FROM produkk"
);

$riwayat = $conn->query("
    SELECT p.PenjualanID,
           p.TanggalPenjualan,
           p.TotalHarga,
           pl.NamaPelanggan
    FROM penjualann p
    JOIN pelanggann pl
    ON p.PelangganID = pl.PelangganID
    ORDER BY p.PenjualanID DESC
");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Transaksi Penjualan</title>
     <link rel="stylesheet" href="style.css">
</head>

<body>

<div class="main">

    <h1>TRANSAKSI PENJUALAN</h1>

    <?php if ($pesan != "") { ?>
        <p><?= htmlspecialchars($pesan) ?></p>
    <?php } ?>

    <form method="POST">

        <label>Nama Pelanggan</label>

        <input type="text"
               name="pelanggan"
               list="daftarPelanggan"
               placeholder="Ketik nama pelanggan"
               required>

        <datalist id="daftarPelanggan">
            <?php while ($p = $pelangganList->fetch_assoc()) { ?>
                <option value="<?= htmlspecialchars($p['NamaPelanggan']) ?>">
            <?php } ?>
        </datalist>

        <h3>Daftar Barang</h3>

        <datalist id="daftarProduk">
            <?php while ($b = $produkList->fetch_assoc()) { ?>
                <option value="<?= htmlspecialchars($b['NamaProduk']) ?>">
            <?php } ?>
        </datalist>

        <div id="daftarBarang">

            <div class="barang">

                <label>Nama Barang</label>

                <input type="text"
                       name="produk[]"
                       list="daftarProduk"
                       placeholder="Ketik nama barang">

                <label>Jumlah Barang</label>

                <input type="number"
                       name="jumlah[]"
                       min="1"
                       placeholder="Masukkan jumlah">

                <hr>

            </div>

        </div>

        <button type="button" onclick="tambahBarang()">
            Tambah Barang
        </button>

        <br><br>

        <button type="submit" name="simpan">
            Simpan Transaksi
        </button>

    </form>

    <h3>Riwayat Transaksi</h3>

    <table border="1" cellpadding="10" cellspacing="0">

        <tr>
            <th>No</th>
            <th>ID Penjualan</th>
            <th>Tanggal</th>
            <th>Pelanggan</th>
            <th>Total Harga</th>
        </tr>

        <?php $no = 1; ?>

        <?php while ($r = $riwayat->fetch_assoc()) { ?>

        <tr>
            <td><?= $no++ ?></td>

            <td><?= $r['PenjualanID'] ?></td>

            <td><?= htmlspecialchars($r['TanggalPenjualan']) ?></td>

            <td><?= htmlspecialchars($r['NamaPelanggan']) ?></td>

            <td>
                Rp <?= number_format($r['TotalHarga'], 0, ',', '.') ?>
            </td>
        </tr>

        <?php } ?>

    </table>

    <br>

    <a href="index.php">Kembali ke Dashboard</a>

</div>

<script>
function tambahBarang() {

    let daftar = document.getElementById("daftarBarang");

    let barang = document.createElement("div");

    barang.className = "barang";

    barang.innerHTML = `
        <label>Nama Barang</label>

        <input type="text"
               name="produk[]"
               list="daftarProduk"
               placeholder="Ketik nama barang">

        <label>Jumlah Barang</label>

        <input type="number"
               name="jumlah[]"
               min="1"
               placeholder="Masukkan jumlah">

        <button type="button"
                onclick="this.parentElement.remove()">
            Hapus Barang
        </button>

        <hr>
    `;

    daftar.appendChild(barang);
}
</script>

</body>
</html>
