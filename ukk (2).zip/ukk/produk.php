<?php
session_start();
require "config.php";
class Produk {
    private $conn;

    public function __construct($conn) {
        $this->conn = $conn;
    }

    public function tambah($nama, $harga, $stok) {
        $nama = mysqli_real_escape_string($this->conn, $nama);

        return mysqli_query($this->conn,
            "INSERT INTO produkk (NamaProduk, Harga, Stok)
             VALUES ('$nama', '$harga', '$stok')");
    }

    public function tampil() {
        return mysqli_query($this->conn,
            "SELECT * FROM produkk ORDER BY ProdukID DESC");
    }

    public function hapus($id) {
        return mysqli_query($this->conn,
            "DELETE FROM produkk WHERE ProdukID='$id'");
    }

    public function edit($id, $nama, $harga, $stok) {
        $nama = mysqli_real_escape_string($this->conn, $nama);

        return mysqli_query($this->conn,
            "UPDATE produkk SET
             NamaProduk='$nama',
             Harga='$harga',
             Stok='$stok'
             WHERE ProdukID='$id'");
    }
}

$produk = new Produk($conn);
$pesan = "";

if (isset($_POST['tambah'])) {
    if ($produk->tambah($_POST['nama'], $_POST['harga'], $_POST['stok'])) {
        $pesan = "Barang berhasil ditambahkan!";
    } else {
        $pesan = "Gagal menambahkan barang!";
    }
}

if (isset($_POST['edit'])) {
    if ($produk->edit($_POST['id'], $_POST['nama'], $_POST['harga'], $_POST['stok'])) {
        $pesan = "Barang berhasil diedit!";
    } else {
        $pesan = "Gagal mengedit barang!";
    }
}

if (isset($_GET['hapus'])) {
    if ($produk->hapus($_GET['hapus'])) {
        $pesan = "Barang berhasil dihapus!";
    } else {
        $pesan = "Barang tidak bisa dihapus karena sudah digunakan dalam transaksi!";
    }
}

$editData = null;

if (isset($_GET['edit'])) {
    $id = (int) $_GET['edit'];
    $hasilEdit = mysqli_query($conn,
        "SELECT * FROM produkk WHERE ProdukID='$id'");
    $editData = mysqli_fetch_assoc($hasilEdit);
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <title>Pendataan Barang</title>
     <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="container">
    <h2>PENDATAAN BARANG</h2>

    <?php if ($pesan != "") { ?>
        <div class="alert"><?php echo $pesan; ?></div>
    <?php } ?>

    <h3><?php echo $editData ? "Edit Barang" : "Tambah Barang"; ?></h3>

    <form method="POST">
        <?php if ($editData) { ?>
            <input type="hidden" name="id" value="<?php echo $editData['ProdukID']; ?>">
        <?php } ?>

        <div class="form-group">
            <label>Nama Barang:</label>
            <input type="text" name="nama"
            value="<?php echo htmlspecialchars($editData['NamaProduk'] ?? ''); ?>" required>
        </div>

        <div class="form-group">
            <label>Harga:</label>
            <input type="number" name="harga"
            value="<?php echo $editData['Harga'] ?? ''; ?>" min="0" required>
        </div>

        <div class="form-group">
            <label>Stok:</label>
            <input type="number" name="stok"
            value="<?php echo $editData['Stok'] ?? ''; ?>" min="0" required>
        </div>

        <?php if ($editData) { ?>
            <button type="submit" name="edit">SIMPAN EDIT</button>
            <a href="produk.php" class="btn-batal">Batal</a>
        <?php } else { ?>
            <button type="submit" name="tambah">TAMBAH BARANG</button>
        <?php } ?>
    </form>

    <hr>

    <h3>Data Barang</h3>

    <table>
        <tr>
            <th>No</th>
            <th>Nama Barang</th>
            <th>Harga</th>
            <th>Stok</th>
            <th>Aksi</th>
        </tr>

        <?php
        $no = 1;
        $data = $produk->tampil();

        while ($row = mysqli_fetch_assoc($data)) {
        ?>
        <tr>
            <td><?php echo $no++; ?></td>
            <td><?php echo htmlspecialchars($row['NamaProduk']); ?></td>
            <td>Rp <?php echo number_format($row['Harga'], 0, ',', '.'); ?></td>
            <td><?php echo $row['Stok']; ?></td>
            <td>
                <a href="produk.php?edit=<?php echo $row['ProdukID']; ?>" class="btn-edit">Edit</a>
                <a href="produk.php?hapus=<?php echo $row['ProdukID']; ?>"
                class="btn-hapus"
                onclick="return confirm('Yakin ingin menghapus barang?')">Hapus</a>
            </td>
        </tr>
        <?php } ?>
    </table>

    <a href="index.php" class="btn-kembali">&larr; Kembali ke Dashboard</a>
</div>

</body>
</html>
