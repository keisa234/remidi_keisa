<?php
include 'config.php';

if (isset($_POST['login'])) {

    $username = $_POST['username'];
    $password = $_POST['password'];

    $sql = mysqli_query($conn,
        "SELECT * FROM loginn WHERE username='$username' AND password='$password'");

    $data = mysqli_fetch_assoc($sql);

    if ($data) {
        $_SESSION['login'] = $data;

        header("Location: index.php");
        exit;

    } else {
        $pesan = "Username atau Password salah!";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login Kasir</title>
     <link rel="stylesheet" href="style.css">
</head>

<body>

<div class="login-container">

    <h2>LOGIN APLIKASI KASIR</h2>

    <p class="subtitle">Silakan masuk ke akun Anda</p>

    <?php if (isset($pesan)) { ?>
        <div class="pesan">
            <?= htmlspecialchars($pesan) ?>
        </div>
    <?php } ?>

    <form method="POST">

        <label>Username</label>
        <input type="text"
               name="username"
               placeholder="Masukkan username"
               required>

        <label>Password</label>
        <input type="password"
               name="password"
               placeholder="Masukkan password"
               required>

        <button type="submit" name="login">
            Login
        </button>

    </form>

    <div class="footer">
        APLIKASI KASIR
    </div>

</div>

</body>
</html>
