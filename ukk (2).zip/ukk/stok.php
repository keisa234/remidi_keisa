
<?php
include 'config.php';
$pesan = "";

if (isset($_POST['update'])) {
    $id = (int)$_POST['ProdukID'];
    $stok = (int)$_POST['Stok'];

    if ($stok < 0) {
        $pesan = "Stok tidak boleh kurang dari 0!";
    } else {
        $stmt = $conn->prepare("
            UPDATE produkk
            SET Stok = ?
            WHERE ProdukID = ?
        ");

        $stmt->bind_param("ii", $stok, $id);

        if ($stmt->execute()) {
            $pesan = "Stok barang berhasil diperbarui!";
        } else {
            $pesan = "Gagal memperbarui stok barang!";
        }
    }
}

$cari = isset($_GET['cari']) ? trim($_GET['cari']) : "";

$stmt = $conn->prepare("
    SELECT * FROM produkk
    WHERE NamaProduk LIKE ?
    ORDER BY ProdukID DESC
");

$keyword = "%" . $cari . "%";
$stmt->bind_param("s", $keyword);
$stmt->execute();
$data = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <title>Stok Barang</title>
     <link rel="stylesheet" href="style.css">
<div class="container">

    <h2>DATA STOK BARANG</h2>

    <?php if ($pesan != "") { ?>
        <div class="pesan">
            <?= htmlspecialchars($pesan) ?>
        </div>
    <?php } ?>

    <form method="GET">
        <input type="text"
               name="cari"
               placeholder="Cari nama barang..."
               value="<?= htmlspecialchars($cari) ?>">

        <button type="submit">Cari</button>
        <a href="stok.php">Reset</a>
    </form>

    <table>
        <tr>
            <th>No</th>
            <th>ID Produk</th>
            <th>Nama Barang</th>
            <th>Harga</th>
            <th>Stok</th>
            <th>Keterangan</th>
            <th>Update Stok</th>
        </tr>

        <?php $no = 1; ?>

        <?php while ($row = $data->fetch_assoc()) { ?>

        <tr>
            <td><?= $no++ ?></td>

            <td><?= $row['ProdukID'] ?></td>

            <td><?= htmlspecialchars($row['NamaProduk']) ?></td>

            <td>
                Rp <?= number_format($row['Harga'], 0, ',', '.') ?>
            </td>

            <td><?= $row['Stok'] ?></td>

            <td>
                <?php if ($row['Stok'] == 0) { ?>
                    <span class="habis">Stok Habis</span>

                <?php } elseif ($row['Stok'] <= 5) { ?>
                    <span class="sedikit">Stok Menipis</span>

                <?php } else { ?>
                    <span class="aman">Stok Aman</span>
                <?php } ?>
            </td>

            <td>
                <form method="POST">
                    <input type="hidden"
                           name="ProdukID"
                           value="<?= $row['ProdukID'] ?>">

                    <input type="number"
                           name="Stok"
                           min="0"
                           value="<?= $row['Stok'] ?>"
                           required
                           style="width:65px">

                    <button type="submit" name="update">
                        Simpan
                    </button>
                </form>
            </td>
        </tr>

        <?php } ?>

    </table>

    <br>

    <a href="index.php">Kembali ke Dashboard</a>

</div>

</body>
</html>
