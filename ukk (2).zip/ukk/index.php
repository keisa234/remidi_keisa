<?php
session_start();
require "config.php";
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Aplikasi Kasir</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="container">
    <h2>DASHBOARD APLIKASI KASIR</h2>
    
    <p class="welcome-text">
        Selamat datang, <strong><?php echo htmlspecialchars($_SESSION['username'] ?? 'Admin'); ?></strong>!Silakan pilih menu di bawah ini untuk mengelola data.
    </p>

    <div class="nav-menu">
        <a href="produk.php">Pendataan Barang</a>
        <a href="stok.php">Kelola Stok</a>
        <a href="transaksi.php">Transaksi Penjualan</a>
        <a href="registrasi.php">Registrasi Petugas</a>
        <a href="pelanggan.php">Daftar Pelanggan</a>
        <a href="logout.php" class="logout" onclick="return confirm('Yakin ingin keluar?')">Logout</a>
    </div>
</div>

</body>
</html>
