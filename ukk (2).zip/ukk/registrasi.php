<?php
include 'config.php';
$pesan = "";

if (isset($_POST['daftar'])) {

    $nama = trim($_POST['nama']);
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    $role = $_POST['role'];

    if ($nama == "" || $username == "" || $password == "") {
        $pesan = "Semua data harus diisi!";
    } elseif (!in_array($role, ['administrator', 'petugas'])) {
        $pesan = "Role tidak valid!";
    } elseif (strlen($password) < 6) {
        $pesan = "Password minimal 6 karakter!";
    } else {

        $passwordHash = password_hash($password, PASSWORD_DEFAULT);

        $stmt = $conn->prepare("
            INSERT INTO loginn (Nama, Username, Password, role)
            VALUES (?, ?, ?, ?)
        ");

        $stmt->bind_param(
            "ssss",
            $nama,
            $username,
            $passwordHash,
            $role
        );

        if ($stmt->execute()) {
            $pesan = "Registrasi berhasil! Akun berhasil ditambahkan.";
        } else {
            if ($conn->errno == 1062) {
                $pesan = "Username sudah digunakan!";
            } else {
                $pesan = "Registrasi gagal!";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <title>Registrasi Akun</title>
     <link rel="stylesheet" href="style.css">
</head>

<body>

<div class="container">

    <h2>REGISTRASI AKUN</h2>

    <?php if ($pesan != "") { ?>
        <div class="pesan">
            <?= htmlspecialchars($pesan) ?>
        </div>
    <?php } ?>

    <form method="POST">

        <label>Nama Lengkap</label>
        <input type="text"
               name="nama"
               placeholder="Masukkan nama lengkap"
               required>

        <label>Username</label>
        <input type="text"
               name="username"
               placeholder="Masukkan username"
               required>

        <label>Password</label>
        <input type="password"
               name="password"
               placeholder="Masukkan password"
               minlength="6"
               required>

        <label>Hak Akses</label>
        <select name="role" required>
            <option value="">-- Pilih Hak Akses --</option>
            <option value="administrator">Administrator</option>
            <option value="petugas">Petugas</option>
        </select>

        <button type="submit" name="daftar">
            Daftar Akun
        </button>

    </form>

    <a href="index.php" class="kembali">
        Kembali ke Dashboard
    </a>

</div>

</body>
</html>
